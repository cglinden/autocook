#define HELLO_WORLD "hello world\n"
